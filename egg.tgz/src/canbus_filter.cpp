// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Filter CAN frames"); }
int main(){
  announce();
  return lionss_run_workload("canbus_filter");
}
