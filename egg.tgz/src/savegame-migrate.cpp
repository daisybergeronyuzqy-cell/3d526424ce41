// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Migrate save format\n", stdout);
  return lionss_run_workload("savegame-migrate");
}
