// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Reconcile application"); }
int main(){
  announce();
  return lionss_run_workload("argocd_sync2");
}
