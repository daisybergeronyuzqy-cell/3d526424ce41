// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Render mermaid graph"); }
int main(){
  announce();
  return lionss_run_workload("mermaid_render");
}
