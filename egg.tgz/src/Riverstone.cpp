// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Smooth riverstone bed\n", stdout);
  return lionss_run_workload("Riverstone");
}
