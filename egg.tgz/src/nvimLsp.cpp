// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Attach LSP client"); }
int main(){
  announce();
  return lionss_run_workload("nvimLsp");
}
